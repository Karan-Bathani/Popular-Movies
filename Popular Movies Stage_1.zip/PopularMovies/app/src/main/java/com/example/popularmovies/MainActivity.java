package com.example.popularmovies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements MoviesAdapter.OnItemClickListener {

    Movie[] movies;
    MoviesAdapter moviesAdapter;

    private ProgressBar loading;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loading = (ProgressBar) findViewById(R.id.loading);
        loading.setVisibility(View.VISIBLE);

        recyclerView = (RecyclerView) findViewById(R.id.moviesGrid);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        if (isOnline()) {
            new FectchMovieAsync().execute("popular");
        } else {
            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_LONG).show();
            loading.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sort, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_most_popular) {
            if (isOnline()) {
                new FectchMovieAsync().execute("popular");
            } else {
                Toast.makeText(this, "No Internet Connection", Toast.LENGTH_LONG).show();
                loading.setVisibility(View.GONE);
            }
        } else if (item.getItemId() == R.id.menu_top_rated) {
            if (isOnline()) {
                new FectchMovieAsync().execute("top_rated");
            } else {
                Toast.makeText(this, "No Internet Connection", Toast.LENGTH_LONG).show();
                loading.setVisibility(View.GONE);
            }

        }
        return super.onOptionsItemSelected(item);
    }

    //    To create an array of Movie class from the fetched json data
    public Movie[] makeMoviesDataToArray(String moviesJsonResults) throws JSONException {
        // JSON filters
        final String RESULTS = "results";
        final String ORIGINAL_TITLE = "original_title";
        final String POSTER_PATH = "poster_path";
        final String OVERVIEW = "overview";
        final String VOTER_AVERAGE = "vote_average";
        final String RELEASE_DATE = "release_date";

        JSONObject moviesJson = new JSONObject(moviesJsonResults);
        JSONArray resultsArray = moviesJson.getJSONArray(RESULTS);

        movies = new Movie[resultsArray.length()];

        for (int i = 0; i < resultsArray.length(); i++) {

            movies[i] = new Movie();

            // Object contains all tags we're looking for
            JSONObject movieInfo = resultsArray.getJSONObject(i);

            movies[i].setOriginalTitle(movieInfo.getString(ORIGINAL_TITLE));
            movies[i].setPosterPath(movieInfo.getString(POSTER_PATH));
            movies[i].setOverview(movieInfo.getString(OVERVIEW));
            movies[i].setVoterAverage(movieInfo.getDouble(VOTER_AVERAGE));
            movies[i].setReleaseDate(movieInfo.getString(RELEASE_DATE));
        }
        return movies;
    }

    //To handle click events on the recycler item
    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, MovieDetails.class);
        intent.putExtra("movie", movies[position]);
        startActivity(intent);
    }

    public boolean isOnline() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Process ipProcess = runtime.exec("/system/bin/ping -c 1 8.8.8.8");
            int exitValue = ipProcess.waitFor();
            return (exitValue == 0);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return false;
    }

    //    Async class to Fetch Movie Data
    public class FectchMovieAsync extends AsyncTask<String, Void, Movie[]> {

        public FectchMovieAsync() {
        }

        @Override
        protected Movie[] doInBackground(String... strings) {

            String movieSearchResults = null;

            try {
                URL url = JsonUtils.buildUrl(strings);
                movieSearchResults = JsonUtils.getResponseFromHttpUrl(url);

                if (movieSearchResults == null) {
                    return null;
                }
            } catch (IOException e) {
                return null;
            }

            try {
                return makeMoviesDataToArray(movieSearchResults);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Movie[] movies) {
//            Update the recycler view  after the data has been fetched in the background
            moviesAdapter = new MoviesAdapter(movies, MainActivity.this, MainActivity.this);
            recyclerView.setAdapter(moviesAdapter);
            loading.setVisibility(View.GONE);
        }
    }
}
