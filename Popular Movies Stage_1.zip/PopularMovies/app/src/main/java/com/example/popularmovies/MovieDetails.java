package com.example.popularmovies;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class MovieDetails extends AppCompatActivity {

    private ImageView ivMovieImage;
    private TextView tvTitle, tvUserRating, tvReleaseDate, tvOverview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        ivMovieImage = (ImageView) findViewById(R.id.ivMovieImage);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvUserRating = (TextView) findViewById(R.id.tvUserRating);
        tvReleaseDate = (TextView) findViewById(R.id.tvReleaseDate);
        tvOverview = (TextView) findViewById(R.id.tvOverview);

        Intent intent = getIntent();

        Movie movie = intent.getParcelableExtra("movie");

        tvTitle.setText(movie.getOriginalTitle());
        tvUserRating.setText (String.valueOf(movie.getVoterAverage ()) + " / 10");
        Picasso.get()
                .load(movie.getPosterPath())
                .fit()
                .error(R.mipmap.ic_launcher_round)
                .placeholder(R.drawable.loading)
                .into(ivMovieImage);

        tvOverview.setText (movie.getOverview ());

        tvReleaseDate.setText (movie.getReleaseDate());
    }
}
